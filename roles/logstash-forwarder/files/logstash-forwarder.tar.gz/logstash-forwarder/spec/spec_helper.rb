require 'rspec'
require 'rspec/mocks'
$: << File.realpath(File.join(File.dirname(__FILE__), "..", "lib"))
